import os
import hashlib

USER_FILE='user.txt'

# hash password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


# load users from file
def load_users():
    users={}
    if os.path.exists(USER_FILE):
        with open('user.txt','r') as f:
            for line in f:
                # print(line)
                parts=line.strip().split(',')
                if len(parts) == 3:
                    username, hashed_password, secret=parts
                    users[username] = (hashed_password, secret)
                    # print(users[username])
    return users

# save all users to file
def save_all_users(users):
    with open('user.txt','w') as f:
        for username, (hashed_password, secret) in users.items():
            f.write(f"{username},{hashed_password},{secret}\n")
            # print(username,':',(hashed_password,secret))

# register
def register():
    users = load_users()
    username = input("Choose a username:")
    if username in users:
        print("Username already exists.")
        return
    password = input("Choose a password:")
    hashe_password=hash_password(password)
    secret = input("Set a secret keyword for your password :")
    users[username] = (hashe_password ,secret)
    save_all_users(users)
    print("Registration successful.")
                

# login
def login():
    users = load_users()
    username = input("Enter your name:")
    password = input("Enter your password:")
    if username in users and users[username][0] == hash_password(password):
        print("Login successful.")
    else:
        print("Invalid password or username.")

# update password
def change_password():
    users = load_users()
    username = input("Choose a username:")
    password = input("Enter your password:")
    if username in users and users[username][0] == hash_password(password):
            new_password = input("Enter your new password")
            users[username] = (hash_password(new_password), users[username][1])
            save_all_users(users)
            print("your password successfully changed.")
    else:
        print("This username doesn't exist.")


# password reset via secret
def password_reset():
    users = load_users()
    secret = input("Enter your secret:")
    username = input("Enter your username:")
    if username in users and users[username][1] == secret:
        new_password = input("Enter your password:")
        hashed_password=hash_password(new_password)
        users[username] = (hashed_password, users[username][1])
        save_all_users(users)
        print("Your password successfully reset.")
    else:
        print("Sorry,This user name or secret doesn't exist here.")

# main function
def main():
    while True:
        print("Simple auth system.")
        print("1. Register.")
        print("2. Login.")
        print("3. Change password.")
        print("4. Reset password via secret.")
        print("5. Exists.")
        while True:
            try:
                choice=int(input("Select an option :"))
            except ValueError:
                print("Enter a number from 1 to 5.")
            else:
                break
        if choice==1:
            register()
        elif choice==2:
            login()
        elif choice==3:
            change_password()
        elif choice==4:
            password_reset()
        elif choice==5:
            print("Thanks for using our authentication.")
            break
if __name__=="__main__":
    main()
            